PB130=function(x) {
  w=length(x)
  m1=mean(x)
  m2=sum((x-m1)^2)
  m3=sum((x-m1)^3)
  m4=sum((x-m1)^4)
  s1=sd(x)
  skew=w*m3/(w-1)/(w-2)/s1^3
  sdskew=sqrt( 6*w*(w-1) / ((w-2)*(w+1)*(w+3)) )
  kurtosis=(w*(w+1)*m4 - 3*m2^2*(w-1)) / ((w-1)*(w-2)*(w-3)*s1^4)
  sdkurtosis=sqrt( 4*(w^2-1) * sdskew^2 / ((w-3)*(w+5)) )
  Zkurtosis=kurtosis/sdkurtosis
  Zskew=skew/sdskew
  mat=matrix(c(skew,kurtosis, sdskew,sdkurtosis, Zskew,Zkurtosis), 2,
             dimnames=list(c("skew","kurtosis"), c("estimate","se","Z")))
  return(mat)
}

